﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vosk;

namespace Deneye
{
    public class Deneye
    {
       
        public class VoskDemo
        {

            [STAThread]
            static void Main()
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Vosk_örnek.Form1());
            }
        }
    }
}
