﻿using NAudio.Wave;
using System;
using System.Windows.Forms;
using Vosk;




namespace Vosk_örnek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static string yol1 = "";
        private WaveInEvent waveIn;
        private Model model;
        private VoskRecognizer recognizer;

        private void button1_Click(object sender, EventArgs e)
        { 
            model = new Model("vosk");
            recognizer = new VoskRecognizer(model, 16000.0f);

            waveIn = new WaveInEvent();
            waveIn.WaveFormat = new WaveFormat(16000, 16, 1);
            waveIn.DataAvailable += WaveIn_DataAvailable;
            waveIn.StartRecording();
        }
        private void WaveIn_DataAvailable(object sender, WaveInEventArgs e)
        {
           recognizer.AcceptWaveform(e.Buffer, e.BytesRecorded);
            yol1 = recognizer.PartialResult();
            label1.Invoke(new Action(() =>
            {
                label1.Text = yol1;
            }));
        }
    }
}
